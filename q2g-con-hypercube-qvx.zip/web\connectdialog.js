/* License
Copyright (c) 2017 Konrad Mattheis und Martin Berthold
Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
define(["require", "exports", "text!./connectdialog.ng.html", "css!./connectdialog.css"], function (require, exports, template) {
    "use strict";
    var ConnectDialog = /** @class */ (function () {
        function ConnectDialog(input, scope) {
            var _this = this;
            this.name = "";
            this.host = "";
            this.username = "";
            this.password = "";
            this.isDesktop = false;
            this.provider = "q2gconhypercubeqvx.exe";
            this.version = "";
            this.info = "Connector for Copy Table.";
            this.isEdit = input.editMode;
            this.scope = scope;
            this.input = input;
            if (this.isEdit) {
                input.serverside.getConnection(input.instanceId).then(function (result) {
                    _this.name = result.qConnection.qName;
                    var connStr = result.qConnection.qConnectionString;
                    var list = connStr.match("host=([^;]*);");
                    if (list.length == 2)
                        _this.host = list[1];
                    else
                        _this.host = "";
                    list = connStr.match("isDesktop=([^;]*);");
                    _this.isDesktop = list.length == 2 && list[1] == "true";
                });
            }
            input.serverside.sendJsonRequest("getUsername").then(function (info) {
                try {
                    _this.username = info.qMessage;
                    _this.olduser = _this.username;
                    _this.password = "**********";
                }
                catch (e) {
                }
            });
            input.serverside.sendJsonRequest("getVersion").then(function (info) {
                try {
                    _this.version = info.qMessage.replace(".Sha.", " Sha.");
                }
                catch (e) {
                }
            });
        }
        Object.defineProperty(ConnectDialog.prototype, "isOkEnabled", {
            get: function () {
                try {
                    return this.name.length > 0;
                }
                catch (ex) {
                    return false;
                }
            },
            enumerable: true,
            configurable: true
        });
        ConnectDialog.prototype.connectionString = function (host) {
            if (!host || this.isDesktop)
                host = "ws://localhost:4848";
            var conString = "CUSTOM CONNECT TO \"provider=" + this.provider + ";host=" + host + ";isDesktop=" + this.isDesktop + ";\"";
            return conString;
        };
        Object.defineProperty(ConnectDialog.prototype, "titleText", {
            get: function () {
                return this.isEdit ? "Change Sense App connection" : "Add Sense App connection";
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(ConnectDialog.prototype, "saveButtonText", {
            get: function () {
                return this.isEdit ? "Save changes" : "Create";
            },
            enumerable: true,
            configurable: true
        });
        ConnectDialog.prototype.onOKClicked = function () {
            var _this = this;
            if (this.name === "") {
                this.connectionInfo = "Please enter a name for the connection.";
            }
            else {
                if (this.isEdit) {
                    var overrideCredentials = this.username !== this.olduser || this.password !== "**********";
                    this.input.serverside.modifyConnection(this.input.instanceId, this.name, this.connectionString(this.host), this.provider, overrideCredentials, this.username, this.password).then(function (result) {
                        if (result) {
                            _this.destroyComponent();
                        }
                    });
                }
                else {
                    {
                        if (typeof this.username === "undefined")
                            this.username = "";
                        if (typeof this.password === "undefined")
                            this.password = "";
                        this.input.serverside.createNewConnection(this.name, this.connectionString(this.host), this.username, this.password);
                        this.destroyComponent();
                    }
                }
            }
        };
        ConnectDialog.prototype.onEscape = function () {
            this.destroyComponent();
        };
        ConnectDialog.prototype.onCancelClicked = function () {
            this.destroyComponent();
        };
        ConnectDialog.prototype.destroyComponent = function () {
            this.scope.destroyComponent();
        };
        return ConnectDialog;
    }());
    return {
        template: template,
        controller: ["$scope", "input", function ($scope, input) {
                $scope.vm = new ConnectDialog(input, $scope);
            }]
    };
});
//# sourceMappingURL=connectdialog.js.map